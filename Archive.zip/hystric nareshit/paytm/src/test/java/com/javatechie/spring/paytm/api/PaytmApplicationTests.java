package com.javatechie.spring.paytm.api;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class PaytmApplicationTests {


	public void contextLoads() {
	}

}
