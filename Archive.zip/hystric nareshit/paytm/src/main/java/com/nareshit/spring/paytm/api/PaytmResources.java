package com.nareshit.spring.paytm.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/paymentService")

public class PaytmResources {
    @GetMapping("/pay")
    public String paymentProcess() {
        return "Payment service called.... Ticket Booked Sucessfully";
    }
}
