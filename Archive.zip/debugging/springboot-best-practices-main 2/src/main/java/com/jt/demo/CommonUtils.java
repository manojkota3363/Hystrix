package com.jt.demo;

import org.springframework.stereotype.Component;

@Component
public class CommonUtils {

    public CommonUtils() {

        System.out.println("CommonUtils bean is created !");
    }
}
